import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { execFileSync } from 'node:child_process';
const source = '/Users/notlaggy/.codex/worktrees/book-finish/gamehackingacademy.github.io/site';
const draft = '/private/tmp/gha-typescript-node-draft/work/site';
const root = '/private/tmp/gha-typescript-node-draft/node-model-fixtures';
const checks = ['check-chat-suggest', 'check-cheatsheets', 'check-handoff-scene-models', 'check-live-scene-models'];
const makers = ['make-handoff-art', 'make-path-sprites', 'scene-png', 'scene-sheet'];
const results = {};
for (const state of ['before', 'after']) {
  const site = path.join(root, state, 'site');
  fs.mkdirSync(path.join(site, 'scripts'), { recursive: true });
  fs.mkdirSync(path.join(site, 'public/scripts'), { recursive: true });
  fs.mkdirSync(path.join(site, 'src/data'), { recursive: true });
  fs.mkdirSync(path.join(site, 'dist/pages/4/06'), { recursive: true });
  if (!fs.existsSync(path.join(site, 'node_modules'))) fs.symlinkSync(path.join(source, 'node_modules'), path.join(site, 'node_modules'));
  if (!fs.existsSync(path.join(site, 'src/scenes'))) fs.symlinkSync(path.join(source, 'src/scenes'), path.join(site, 'src/scenes'));
  if (!fs.existsSync(path.join(site, 'public/assets'))) fs.mkdirSync(path.join(site, 'public/assets'), { recursive: true });
  for (const file of ['public/scripts/chat-suggest.js', 'src/data/handoff-figures.json', 'dist/pages/4/06/index.html']) {
    fs.copyFileSync(path.join(source, file), path.join(site, file));
  }
  results[state] = {};
  for (const name of [...checks, ...makers]) {
    // The first attempt completed these six original checks/generators before
    // hitting an existing stale .mjs scene path. Retain their success and files.
    if (state === 'before' && name !== 'scene-png' && name !== 'scene-sheet') {
      results[state][name] = 'Passed in first baseline run';
      continue;
    }
    let code = fs.readFileSync(path.join(state === 'before' ? source : draft, `scripts/${name}.${state === 'before' ? 'mjs' : 'ts'}`), 'utf8');
    // Original scripts already use the integrated TS scenes and helpers. Give
    // each isolated copy those exact dependencies; generated files stay private.
    code = code.replace(/(['"])\.\.\/src\/lib\/([^'"]+)\1/g, (_m, quote, file) => quote + pathToFileURL(path.join(source, 'src/lib', file.replace(/\.mjs$/, '.ts'))).href + quote);
    code = code.replace(/(['"])\.\.\/src\/scenes\/\$\{name\}\.ts\1/g, (_m, quote) => quote + pathToFileURL(path.join(source, 'src/scenes')).href + '/${name}.ts' + quote);
    // Adapt the baseline's stale dynamic lookup to the already-integrated
    // scene file suffix. This path repair is included in the typed tools.
    if (state === 'before' && (name === 'scene-png' || name === 'scene-sheet')) code = code.replaceAll('${name}.mjs', '${name}.ts');
    const implementation = path.join(site, 'scripts', `${name}.${state === 'before' ? 'mjs' : 'ts'}`);
    fs.writeFileSync(implementation, code);
    if (state === 'after') fs.writeFileSync(path.join(site, 'scripts', `${name}.mjs`), `export * from './${name}.ts';\n`);
    const args = ['scripts/' + name + '.mjs'];
    if (name === 'scene-png' || name === 'scene-sheet') args.push(path.join(root, state, 'output'), 'bfs-around-wall', 'world-to-screen');
    const output = execFileSync(process.execPath, args, { cwd: site, env: { ...process.env, CHEATSHEET_SITE: source }, encoding: 'utf8' });
    results[state][name] = output.replaceAll(path.join(root, state), '<fixture>');
  }
}
for (const name of ['scene-png', 'scene-sheet']) assert.equal(results.after[name], results.before[name], name + ' command output differs');
function files(directory) {
  return fs.readdirSync(directory, { withFileTypes: true }).flatMap(entry => entry.isDirectory() ? files(path.join(directory, entry.name)) : [path.join(directory, entry.name)]);
}
let outputs = 0;
for (const subdir of ['site/public/assets/images/original', 'output']) {
  const before = path.join(root, 'before', subdir);
  const after = path.join(root, 'after', subdir);
  const relative = files(before).map(file => path.relative(before, file));
  assert.deepEqual(files(after).map(file => path.relative(after, file)), relative);
  for (const name of relative) {
    assert.deepEqual(fs.readFileSync(path.join(after, name)), fs.readFileSync(path.join(before, name)), name);
    outputs++;
  }
}
const report = { runtime: process.version, commands: 8, commandExecutions: 16, byteIdenticalOutputs: outputs, baselineScenePathAdapted: true, output: results.after };
fs.writeFileSync('/private/tmp/gha-typescript-node-draft/node-model-equivalence.json', JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
