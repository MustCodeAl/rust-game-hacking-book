# Recovered strict scene subset

Apply scene-ready.patch after the current publication freeze. It migrates52definitions +9pure helpers, adds discriminated actor/timeline/scene-module interfaces, narrows CURRENT Scene.astro imports/glob/field types, and updates four Node scene-tool import/filter suffixes. Scene data, IDs, CSS, controls, audio/print fallback and assets remain.

Root-owned runtime.js needs only the eight import/dynamic-import suffix changes in scene-runtime-imports.patch. Its authored browser logic is untouched. Apply this companion hunk together, or port those exact imports while converting runtime yourself.

Strict gate: installed TypeScript5.9.3, `node site/node_modules/typescript/bin/tsc -p site/tsconfig.scenes.json`. strict/noEmit/allowImportingTsExtensions/verbatimModuleSyntax/erasableSyntaxOnly. All62files pass. Native Node26.10.0 imports every typed scene. Current-source equivalence passes52scene/player contracts,422state/rendered-SVG snapshots and37default/field-extreme explorer cases. No lab or game/example binary executed.

Missing BFS parent-actor mappings now give a clear early error instead of an invalid timeline identifier. Message options are required rather than asserted from an unsafe empty object; every current caller provides them. Grid options separate its label callback from the boolean actor fill flag. These are proper checked types, not filename-only renames.

Four .mjs tool bodies remain CURRENT pending their next typed subset; only scene import/filter suffixes change here. Protected shared map/plugin/appearance/github modules are excluded. No package changes yet.
