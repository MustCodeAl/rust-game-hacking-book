/** Contracts shared by the bounded worked trace models and their Node checks. */
export type TraceValue = string | number | boolean | null | undefined;
export type TraceVars = Record<string, TraceValue>;
export interface TraceMemoryCell { label: string; value: string; note?: string; active?: boolean }
export interface TraceMemory { title: string; cells: TraceMemoryCell[] }
export interface TraceStep { line: number; say: string; vars: TraceVars; mem?: TraceMemory }
export interface RangeInput<Id extends string = string> {
  id: Id; label: string; type: 'range'; min: number; max: number; step: number; value: number;
}
export interface SelectInput<Id extends string = string, Value extends string = string> {
  id: Id; label: string; type: 'select'; value: Value; options: { value: Value; label: string }[];
}
export type TraceInput = RangeInput | SelectInput;
export type InputValue<I extends TraceInput> = I extends RangeInput ? number : I extends SelectInput<string, infer Value> ? Value : never;
export type InputValues<Inputs extends readonly TraceInput[]> = {
  [I in Inputs[number] as I['id']]: InputValue<I>;
};
export interface TraceDefinition<Inputs extends readonly TraceInput[] = readonly TraceInput[]> {
  title: string; intro: string; inputs: Inputs;
  code: string[] | ((values: InputValues<Inputs>) => string[]);
  run(values: InputValues<Inputs>): TraceStep[];
}
export interface TraceRecorder {
  steps: TraceStep[];
  add(line: number, say: string, changes?: TraceVars, memory?: TraceMemory): void;
}
export type TraceAdd = TraceRecorder['add'];
export const defineTrace = <const Inputs extends readonly TraceInput[]>(trace: TraceDefinition<Inputs>): TraceDefinition<Inputs> => trace;
export function range<const Id extends string>(id: Id, label: string, min: number, max: number, value: number, step = 1): RangeInput<Id> {
  return { id, label, type: 'range', min, max, step, value };
}
export function select<const Id extends string, const Options extends readonly (readonly [string, string])[]>(
  id: Id, label: string, value: Options[number][0], options: Options,
): SelectInput<Id, Options[number][0]> {
  return { id, label, type: 'select', value, options: options.map(([value, label]) => ({ value, label })) };
}
