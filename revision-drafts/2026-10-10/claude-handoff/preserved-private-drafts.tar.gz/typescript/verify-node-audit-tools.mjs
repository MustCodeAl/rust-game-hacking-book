import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import vm from 'node:vm';
import ts from '/Users/notlaggy/.codex/worktrees/book-finish/gamehackingacademy.github.io/site/node_modules/typescript/lib/typescript.js';
const root = '/private/tmp/gha-typescript-node-draft';
const source = '/Users/notlaggy/.codex/worktrees/book-finish/gamehackingacademy.github.io/site';
const draft = root + '/work/site';
const names = ['check-comment-toggle','check-concept-diagrams','check-contrast','check-handoff-art','check-handoff-scenes','check-reader-accessibility','check-reader-controls','check-reader-keyboard','check-reader-scenes','check-reader-scroll','check-scene-browser','check-simulation-editors','check-speedtype-recall','make-concept-art'];
const assertionCounts = {};
for (const name of names) {
  const before = fs.readFileSync(`${source}/scripts/${name}.mjs`, 'utf8');
  const after = fs.readFileSync(`${draft}/scripts/${name}.ts`, 'utf8');
  const tree = ts.createSourceFile(name + '.ts', after, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  const banned = [];
  const visit = node => { if (node.kind === ts.SyntaxKind.AnyKeyword) banned.push(node.getStart(tree)); ts.forEachChild(node, visit); };
  visit(tree);
  assert.deepEqual(banned, [], name + ' has no authored any');
  assert.ok(!/ts-(?:nocheck|ignore)/.test(after));
  const assertions = code => [...code.matchAll(/assert\.(\w+)\(/g)].reduce((counts, match) => ({ ...counts, [match[1]]: (counts[match[1]] || 0) + 1 }), {});
  const a = assertions(before), b = assertions(after);
  for (const [kind, count] of Object.entries(a)) assert.ok((b[kind] || 0) >= count, name + ' retained ' + kind + ' checks');
  assertionCounts[name] = { before: a, after: b };
}
function functions(state, names) {
  const code = fs.readFileSync(`${state === 'before' ? source : draft}/scripts/check-speedtype-recall.${state === 'before' ? 'mjs' : 'ts'}`, 'utf8');
  const tree = ts.createSourceFile('check.ts', code, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  const pieces = tree.statements.filter(node => ts.isFunctionDeclaration(node) && names.includes(node.name?.text)).map(node => node.getText(tree)).join('\n');
  const js = ts.transpileModule(pieces, { compilerOptions: { target: ts.ScriptTarget.ES2022 } }).outputText;
  return vm.runInNewContext(js + ';({lexicalTokens,fitsFocus,explicitCandidates})');
}
const oldOracle = functions('before', ['lexicalTokens','fitsFocus','explicitCandidates']);
const newOracle = functions('after', ['lexicalTokens','fitsFocus','explicitCandidates']);
const fixtures = ['OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, false, pid)', 'use windows::Win32::Foundation::{CloseHandle, HANDLE};', 'let next: u32 = index * 624 + 4;', 'x >= 4 && y != 0; 0.125 + 0xFF', '🙂 alpha::beta::<T>(item); a >>= 2;'];
let oracleCases = 0;
for (const fixture of fixtures) {
  assert.equal(JSON.stringify(newOracle.lexicalTokens(fixture)), JSON.stringify(oldOracle.lexicalTokens(fixture)));
  oracleCases++;
}
const code = fixtures.join('\n');
const fragments = [{text: fixtures[0],mask:'OpenProcess',kind:'api'}, {text: fixtures[0],mask:'false',kind:'argument'}, {text: fixtures[1],mask:'CloseHandle',kind:'import'}, {text: fixtures[2],mask:'u32',kind:'type'}, {text: fixtures[2],mask:'*',kind:'logic'}];
for (const focus of ['mixed','calls','imports','logic']) {
  assert.equal(JSON.stringify(newOracle.explicitCandidates(code, fragments, focus)), JSON.stringify(oldOracle.explicitCandidates(code, fragments, focus)));
  for (const kind of ['api','argument','import','type','logic',undefined]) {
    assert.equal(newOracle.fitsFocus(kind, focus), oldOracle.fitsFocus(kind, focus));
    oracleCases++;
  }
}
const fixtureRoot = root + '/node-audit-fixtures';
for (const state of ['before', 'after']) {
  const site = `${fixtureRoot}/${state}/site`;
  fs.mkdirSync(`${site}/scripts`, { recursive: true });
  if (!fs.existsSync(`${site}/node_modules`)) fs.symlinkSync(`${source}/node_modules`, `${site}/node_modules`);
  const ext = state === 'before' ? 'mjs' : 'ts';
  fs.copyFileSync(`${state === 'before' ? source : draft}/scripts/make-concept-art.${ext}`, `${site}/scripts/make-concept-art.${ext}`);
  if (state === 'after') fs.writeFileSync(`${site}/scripts/make-concept-art.mjs`, "export * from './make-concept-art.ts';\n");
  execFileSync(process.execPath, ['scripts/make-concept-art.mjs'], { cwd: site, encoding: 'utf8' });
}
const artifactDir = '/site/public/assets/images/original';
const files = fs.readdirSync(fixtureRoot + '/before' + artifactDir).sort();
assert.equal(files.length, 6);
assert.deepEqual(fs.readdirSync(fixtureRoot + '/after' + artifactDir).sort(), files);
for (const file of files) assert.deepEqual(fs.readFileSync(fixtureRoot + '/after' + artifactDir + '/' + file), fs.readFileSync(fixtureRoot + '/before' + artifactDir + '/' + file), file);
const contrast = fs.readFileSync(draft + '/scripts/check-contrast.ts', 'utf8');
for (const term of ["getContext('2d',{colorSpace:'srgb',willReadFrequently:true})", "CSS.supports('color',c)", 'getImageData(0,0,1,1)', "CONTRAST_APPEARANCE==='modern'"]) assert.ok(contrast.includes(term), 'Current CSS Color4/Modern path preserved');
const report = { runtime: process.version, typedTools: names.length, noAnyOrSuppressions: true, originalAssertionsRetained: true, independentOracleEquivalenceCases: oracleCases, byteIdenticalArtworkFiles: files.length, assertionCounts };
fs.writeFileSync(root + '/node-audit-equivalence.json', JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ ...report, assertionCounts: undefined }, null, 2));
