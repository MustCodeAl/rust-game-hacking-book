import fs from 'node:fs';
import ts from '/Users/notlaggy/.codex/worktrees/book-finish/gamehackingacademy.github.io/site/node_modules/typescript/lib/typescript.js';
const sourceRoot = '/Users/notlaggy/.codex/worktrees/book-finish/gamehackingacademy.github.io/site/src/scripts/';
const targetRoot = '/private/tmp/gha-typescript-node-draft/work/site/src/scripts/';
for (const name of ['assembly-traces','original-traces','rust-idiom-traces','scene-traces','handoff-traces']) {
  let code = fs.readFileSync(sourceRoot + name + '.js', 'utf8');
  const tree = ts.createSourceFile(name + '.js', code, ts.ScriptTarget.Latest, true, ts.ScriptKind.JS);
  const patches = [];
  function visit(node) {
    if (ts.isObjectLiteralExpression(node)) {
      const names = new Set(node.properties.map(property => property.name && (ts.isIdentifier(property.name) || ts.isStringLiteral(property.name)) ? property.name.text : ''));
      if (names.has('title') && names.has('intro') && names.has('inputs') && names.has('code') && names.has('run')) {
        const start = node.getStart(tree), end = node.getEnd();
        // Generic model factories get their own typed signatures below.
        if (!names.has('execute') && node.properties.some(p => p.name?.getText(tree) === 'inputs' && ts.isPropertyAssignment(p))) patches.push({ start, end, text: 'defineTrace(' + code.slice(start, end) + ')' });
      }
    }
    ts.forEachChild(node, visit);
  }
  visit(tree);
  for (const patch of patches.sort((a,b) => b.start - a.start)) code = code.slice(0, patch.start) + patch.text + code.slice(patch.end);
  code = code.replace(/^const range\s*=.*\n/m, '').replace(/^const (?:select|choose)\s*=.*\n/m, '');
  code = "import { range, select, defineTrace } from './trace-model.ts';\nimport type { TraceDefinition, TraceInput, InputValues, TraceValue, TraceVars, TraceStep, TraceMemory, TraceRecorder, TraceAdd } from './trace-model.ts';\n" + code;
  if (name === 'scene-traces') code = code.replaceAll('choose(', 'select(');
  fs.writeFileSync(targetRoot + name + '.ts', code);
}
