# Shared/data/plugin strict migration

shared-ready.patch converts16CURRENT modules to typed .ts implementations, removes their old mjs bodies, updates dependent import specifiers without overwriting CURRENT Astro markup/CSS/source preview behavior, and adds a scoped strict gate. All current chapter titles/order/identity rules, immutable HAST replaceNode handling, sourceInfo.text and appearance rows are preserved. Archive is used only as annotation starting material for unchanged bodies.

Apply shared-root-imports.patch separately for root-owned astro.config.mjs and reader-tools.js import specifiers only; port them to your own latest versions if needed. No bootstrap/runtime behavior changes. These dependency rewrites must accompany module replacement. Node CLI filenames remain .mjs at this stage; only their shared imports point at native Node26 TS. Generated CLI compatibility entries arrive with the next Node tools subset.

package-types-ready.patch adds exact installed TypeScript5.9.3 and Node26/types/check versions to CURRENT package.json, preserving scripts/dependencies. Never use the archive's permissive TypeScript^5.0.0, which can select incompatible future majors. Root owns dependency install/lockfile integration.

Scoped strict gate: node site/node_modules/typescript/bin/tsc -p site/tsconfig.shared.json (strict,verbatimModuleSyntax,erasableSyntaxOnly,noEmit). Passes. Current-source equivalence:155rendered lesson fixtures and25,681readable blocks/media/speech chunks;155identity entries;3native Satteri compiler fixtures with actual rewritten-label/table-wrapper/diagram-hash effects;3math renders;sourceInfo.text/reference/served metadata across3real files;first-paint export parses as JavaScript with current appearance keys. No lab/example binaries or full site build executed.

Root must run assembled Astro/Vite integration and normal browser/source checks after applying. Remaining39Node tool bodies are still drafting; do not publish their private incomplete files.
