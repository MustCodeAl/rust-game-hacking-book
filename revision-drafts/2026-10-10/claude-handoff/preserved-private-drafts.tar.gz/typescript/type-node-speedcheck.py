from pathlib import Path
file = Path('/private/tmp/gha-typescript-node-draft/work/site/scripts/check-speedtype-recall.ts')
source = file.read_text()
replacements = [
    ("import assert from 'node:assert/strict';", "import assert from 'node:assert/strict';\nimport type { Locator } from 'playwright';\ntype RecallKind = 'api' | 'argument' | 'import' | 'type' | 'logic';\ninterface RecallFragment { text: string; hint: string; mask?: string; kind?: RecallKind }\ninterface LexicalToken { start: number; end: number; token: string }\ntype TypingAuditWindow = Window & { __speedtypeSpanReads: number };"),
    ('function lexicalTokens(source)', 'function lexicalTokens(source: string): LexicalToken[]'),
    ('function fitsFocus(kind, focus)', 'function fitsFocus(kind: RecallKind | undefined, focus: string)'),
    ('function explicitCandidates(source, fragments, focus)', 'function explicitCandidates(source: string, fragments: RecallFragment[], focus: string)'),
    ('async function inspectMasks(panel, source, fragments, id)', 'async function inspectMasks(panel: Locator, source: string, fragments: RecallFragment[], id: string)'),
    ('async function readableMask(panel)', 'async function readableMask(panel: Locator): Promise<string>'),
    ('new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)))', 'new Promise<number>(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)))'),
    ("return panel.locator('[data-speedtype-readable]').textContent();", "const text = await panel.locator('[data-speedtype-readable]').textContent();\n  assert.notEqual(text, null, 'Readable practice copy exists');\n  return text!;"),
    ('window.__speedtypeSpanReads = 0;', 'const auditWindow = window as TypingAuditWindow;\n      auditWindow.__speedtypeSpanReads = 0;'),
    ("if (descriptor?.get && descriptor.set) Object.defineProperty(Node.prototype, 'textContent', {", "if (descriptor?.get && descriptor.set) {\n        const getText = descriptor.get as (this: Node) => string | null;\n        const setText = descriptor.set as (this: Node, value: string | null) => void;\n        Object.defineProperty(Node.prototype, 'textContent', {"),
    ('get() {', 'get(this: Node) {'),
    ('window.__speedtypeSpanReads++;', 'auditWindow.__speedtypeSpanReads++;'),
    ('return descriptor.get.call(this);', 'return getText.call(this);'),
    ('set(value) { descriptor.set.call(this, value); },', 'set(this: Node, value: string | null) { setText.call(this, value); },'),
    ('      });\n    });\n    const page', '      });\n      }\n    });\n    const page'),
    ('const errors = [], onError = error =>', 'const errors: string[] = [], onError = (error: Error) =>'),
    ("assert.equal((await page.goto(`${base}pages/${lesson.path}/`, { waitUntil: 'domcontentloaded' })).status(), 200);", "const response = await page.goto(`${base}pages/${lesson.path}/`, { waitUntil: 'domcontentloaded' });\n      assert.ok(response, lesson.path + ' returned a response');\n      assert.equal(response.status(), 200);"),
    ("const fragments = JSON.parse(await root.getAttribute('data-speedtype-recall') || '[]');", "assert.ok(id, 'Drill has a stable ID');\n        const fragments: RecallFragment[] = JSON.parse(await root.getAttribute('data-speedtype-recall') || '[]');"),
    ('const typeLines = async text =>', 'const typeLines = async (text: string) =>'),
    ('assert.equal(masked.trim(), visibleMasked.trim());', "assert.ok(visibleMasked);\n        assert.equal(masked.trim(), visibleMasked.trim());"),
    ("const all = [...node.closest('.kit-speedtype__code').querySelectorAll('.st-c')];", "const code = node.closest('.kit-speedtype__code');\n          if (!code) throw new Error('Practice character has no code container');\n          const all = [...code.querySelectorAll('.st-c')];"),
    ('() => window.__speedtypeSpanReads', '() => (window as TypingAuditWindow).__speedtypeSpanReads'),
    ('options.map(option => option.value)', 'options.map(option => (option as HTMLOptionElement).value)'),
    ("(await panel.locator('[data-speedtype-readable]').textContent()).includes", "(await panel.locator('[data-speedtype-readable]').textContent() ?? '').includes"),
]
for old, new in replacements:
    if old not in source: raise ValueError(f'missing {old!r}')
    source = source.replace(old, new)
file.write_text(source)
