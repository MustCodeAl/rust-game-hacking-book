from pathlib import Path
import difflib
import json
import subprocess

ROOT = Path('/private/tmp/gha-typescript-node-draft')
SITE = Path('/Users/notlaggy/.codex/worktrees/book-finish/gamehackingacademy.github.io/site')
DRAFT = ROOT / 'work/site'
NAMES = ['check-chat-suggest', 'check-cheatsheets', 'check-handoff-scene-models', 'check-live-scene-models', 'make-handoff-art', 'make-path-sprites', 'scene-png', 'scene-sheet']
manifest_file = DRAFT / 'scripts/generated-compatibility.json'
before_manifest = manifest_file.read_text()
manifest = json.loads(before_manifest)
manifest['entries'] += [{'entry': name + '.mjs', 'implementation': name + '.ts'} for name in NAMES]
manifest['entries'].sort(key=lambda row: row['entry'])
manifest_file.write_text(json.dumps(manifest, indent=2) + '\n')
subprocess.run(['rtk', 'proxy', 'node', 'scripts/generate-compat-entries.ts'], cwd=DRAFT, check=True)
subprocess.run(['rtk', 'proxy', 'node', 'scripts/generate-compat-entries.ts', '--check'], cwd=DRAFT, check=True)
actions = []
for name in NAMES:
    actions.append((f'site/scripts/{name}.ts', '', (DRAFT / f'scripts/{name}.ts').read_text()))
    actions.append((f'site/scripts/{name}.mjs', (SITE / f'scripts/{name}.mjs').read_text(), (DRAFT / f'scripts/{name}.mjs').read_text()))
actions.append(('site/scripts/generated-compatibility.json', before_manifest, manifest_file.read_text()))
actions.append(('site/tsconfig.model-tools.json', '', (DRAFT / 'tsconfig.model-tools.json').read_text()))
fixture = ROOT / 'node-model-apply-fixture'
fixture.mkdir(exist_ok=True)
chunks = []
for name, before, after in actions:
    chunks.append(''.join(difflib.unified_diff(before.splitlines(keepends=True), after.splitlines(keepends=True), fromfile='a/' + name if before else '/dev/null', tofile='b/' + name)))
    if before:
        file = fixture / name
        file.parent.mkdir(parents=True, exist_ok=True)
        file.write_text(before)
patch = ROOT / 'node-model-tools-ready.patch'
patch.write_text(''.join(chunks))
subprocess.run(['rtk', 'git', 'init', '-q'], cwd=fixture, check=True)
subprocess.run(['rtk', 'git', 'apply', '--check', str(patch)], cwd=fixture, check=True)
report = {'ready': True, 'dependency': 'node-build-tools-ready.patch (first seven aliases)', 'newTools': NAMES, 'strictGate': 'tsconfig.model-tools.json', 'aliasEntries': len(manifest['entries']), 'fileActions': len(actions), 'patchDryCheck': True, 'qa': json.loads((ROOT / 'node-model-equivalence.json').read_text())}
(ROOT / 'node-model-tools-ready.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: v for k, v in report.items() if k != 'qa'}, indent=2))
