from pathlib import Path
ROOT = Path('/private/tmp/gha-typescript-node-draft/work/site/scripts')
def revise(name, replacements):
    file = ROOT / name
    source = file.read_text()
    for old, new in replacements:
        if old not in source: raise ValueError(f'{name}: missing {old!r}')
        source = source.replace(old, new)
    file.write_text(source)

revise('check-contrast.ts', [
    ("const b=await", "interface ContrastFailure { sel: string; ratio: number; need: number; txt: string }\ntype RGBA = [number, number, number, number];\nconst b=await"),
    ('([pal,mode,noteLessons,appearance])=>', '([pal,mode,noteLessons,appearance]: [string, string, string[], string])=>'),
    (',[pal,mode,noteLessons,appearance]);', ',[pal,mode,noteLessons,appearance] as [string, string, string[], string]);'),
    ('const agg={};', 'const agg: Record<string, ContrastFailure & { n: number }>={};'),
    ('nodes=>nodes.forEach(node=>node.open=true)', 'nodes=>nodes.forEach(node=>(node as HTMLDetailsElement).open=true)'),
    ('const colorCache=new Map();', 'const colorCache=new Map<string, RGBA>();'),
    ('const parse=c=>', 'const parse=(c: string): RGBA=>'),
    ('if(colorCache.has(c))return colorCache.get(c);', 'const cached=colorCache.get(c);if(cached)return cached;'),
    ('const parsed=[rgba[0],rgba[1],rgba[2],rgba[3]/255];', 'const parsed: RGBA=[rgba[0],rgba[1],rgba[2],rgba[3]/255];'),
    ('const lum=([r,g,b])=>{const f=v=>', 'const lum=([r,g,b]: RGBA)=>{const f=(v: number)=>'),
    ('const over=(fg,bg)=>', 'const over=(fg: RGBA,bg: RGBA): RGBA=>'),
    ('const bgOf=el=>{const layers=[];for(let e=el;', 'const bgOf=(el: HTMLElement): RGBA=>{const layers: RGBA[]=[];for(let e: HTMLElement | null=el;'),
    ('let base=[255,255,255,1];', 'let base: RGBA=[255,255,255,1];'),
    ('const out=[];const seen=new Set();', 'const out: ContrastFailure[]=[];const seen=new Set<Element>();'),
    ('const t=n.nodeValue.trim();', "const t=(n.nodeValue ?? '').trim();"),
    ("(el.className&&el.className.baseVal===undefined?el.className:'')", "(el.className&&typeof el.className==='string'?el.className:'')"),
])
revise('check-reader-accessibility.ts', [
    ('const results = [];', '''interface AuditNode { target: (string | string[])[]; failureSummary?: string }
interface AuditRule { id: string; impact?: string | null; nodes: AuditNode[] }
interface AxeAPI { run(document: Document, options: { runOnly: { type: string; values: string[] }; resultTypes: string[] }): Promise<{ violations: AuditRule[]; incomplete: AuditRule[] }> }
interface AuditFinding { id: string; impact?: string | null; nodes: { target: (string | string[])[]; summary?: string }[] }
interface AuditState { width: number; lesson: string; state: string; errors: string[]; violations: AuditFinding[]; incomplete: AuditFinding[] }
const results: AuditState[] = [];'''),
    ('assert.equal(response.status(), 200);', "assert.ok(response, lesson + ' returned a response');\n      assert.equal(response.status(), 200);"),
    ('const scan = async state =>', 'const scan = async (state: string) =>'),
    ('const data = await window.axe.run', "const auditWindow = window as Window & { axe: AxeAPI };\n          const data = await auditWindow.axe.run"),
])
