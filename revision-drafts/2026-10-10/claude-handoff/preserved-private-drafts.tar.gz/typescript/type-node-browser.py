from pathlib import Path
ROOT = Path('/private/tmp/gha-typescript-node-draft/work/site/scripts')
def revise(name, replacements):
    file = ROOT / name
    source = file.read_text()
    for old, new in replacements:
        if old not in source: raise ValueError(f'{name}: missing {old!r}')
        source = source.replace(old, new)
    file.write_text(source)

for file in ROOT.glob('check-*.ts'):
    source = file.read_text()
    source = source.replace("JSON.parse(localStorage.getItem('gha-bubbles:pages/10/02'))", "JSON.parse(localStorage.getItem('gha-bubbles:pages/10/02') ?? 'null')")
    source = source.replace("document.querySelector('.margin-note--mine')?.dataset", "document.querySelector<HTMLElement>('.margin-note--mine')?.dataset")
    source = source.replace("document.querySelector('[data-lesson-notes]')?.dataset", "document.querySelector<HTMLElement>('[data-lesson-notes]')?.dataset")
    file.write_text(source)
revise('check-comment-toggle.ts', [
    ('selection.removeAllRanges(); selection.addRange(range);', "if (!selection) throw new Error('Selection API unavailable'); selection.removeAllRanges(); selection.addRange(range);"),
    ('getSelection().removeAllRanges()', 'getSelection()?.removeAllRanges()'),
])
revise('check-reader-controls.ts', [
    ('const setComments = async value =>', "const setComments = async (value: 'hide' | 'show') =>"),
    ('const chooseComments = async value =>', "const chooseComments = async (value: 'hide' | 'show') =>"),
    ('onlyErrors = [];', 'onlyErrors: string[] = [];'),
    ("includes(document.documentElement.dataset.noteMode)", "includes(document.documentElement.dataset.noteMode ?? '')"),
])
revise('check-reader-scroll.ts', [
    ('const intervals = []; let last;', 'const intervals: number[] = []; let last: number | undefined;'),
    ('const at = await new Promise(', 'const at = await new Promise<number>('),
    ('round = n =>', 'round = (n: number) =>'),
    ('round(sorted.at(-1))', 'round(sorted[sorted.length - 1])'),
])
revise('check-handoff-art.ts', [
    ('const records = JSON.parse', 'interface HandoffFigure { asset: string; sha256: string; lesson: string; alt: string; caption: string }\nconst records: HandoffFigure[] = JSON.parse'),
    ('const onError = error =>', 'const onError = (error: Error) =>'),
    ('assert.equal(response.status()', "assert.ok(response, record.lesson + ' returned a response');\n      assert.equal(response.status()"),
    ('image.evaluate(async image =>', 'image.evaluate(async (image: HTMLImageElement) =>'),
    ('new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)))', 'new Promise<number>(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)))'),
])
revise('check-scene-browser.ts', [
    ('const items=JSON.parse', 'interface AuditScene { name: string; hosts: { path: string }[] }\nconst items: AuditScene[]=JSON.parse'),
    ('const errors=[];', 'const errors: string[]=[];'),
    ('assert.equal(response.status(),200);', "assert.ok(response, 'Scene page returned a response');assert.equal(response.status(),200);"),
    ('scrub.evaluate((e,v)=>{e.value=v;', 'scrub.evaluate((e: HTMLInputElement,v)=>{e.value=String(v);'),
])
