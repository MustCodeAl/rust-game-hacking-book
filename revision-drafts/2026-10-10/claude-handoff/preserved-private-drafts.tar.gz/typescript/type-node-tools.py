from pathlib import Path
import re

ROOT = Path('/private/tmp/gha-typescript-node-draft/work/site/scripts')
for file in ROOT.glob('*.ts'):
    source = file.read_text()
    updated = re.sub(
        r'const \{\s*(chromium)\s*\} = (require\([^\n;]*\)|createRequire\(import.meta.url\)\([^\n;]*\));',
        lambda m: f"const {{ {m[1]} }}: typeof import('playwright') = {m[2]};",
        source,
    )
    updated = updated.replace('const {chromium}=createRequire', "const { chromium }: typeof import('playwright') = createRequire")
    updated = updated.replace('errors = [];', 'errors: string[] = [];')
    if updated != source:
        file.write_text(updated)
        print(file.name)

def revise(name, replacements):
    file = ROOT / name
    source = file.read_text()
    for old, new in replacements:
        if old not in source:
            raise ValueError(f'{name}: missing {old!r}')
        source = source.replace(old, new)
    file.write_text(source)

revise('check-handoff-scene-models.ts', [
    ('popcount = n =>', 'popcount = (n: number) =>'),
    ('model.rounds.at(-1).count', 'model.rounds.at(-1)?.count'),
    ("for (const key of ['x', 'y', 'o'])", "for (const key of ['x', 'y', 'o'] as const)"),
])
revise('check-live-scene-models.ts', [
    ('(actual, expected) =>', '(actual: number, expected: number) =>'),
    ('if (visible) { close(point.pixel[0]', "if (visible) { assert.ok(point.pixel, 'Accepted point has pixels'); close(point.pixel[0]"),
    ('const worked = projectionModel();', "const worked = projectionModel();\nassert.ok(worked.nearer.pixel); assert.ok(worked.farther.pixel);"),
])
for name in ['scene-png.ts', 'scene-sheet.ts']:
    revise(name, [
        ("import { renderScene }", "import type { SceneModule } from '../src/lib/scene/types.ts';\nimport { renderScene }"),
        ("endsWith('.mjs')", "endsWith('.ts')"),
        ('slice(0, -4)', 'slice(0, -3)'),
        ('const sc = (await import(pathToFileURL(new URL(`${name}.mjs`, scenesDir).pathname))).default;', 'const sc = (await import(pathToFileURL(new URL(`${name}.ts`, scenesDir).pathname).href) as SceneModule).default;'),
        ('const settle = (i) =>', 'const settle = (i: number) =>'),
        ("({ '&': '&amp;', '<': '&lt;', '>': '&gt;' })[c]", "({ '&': '&amp;', '<': '&lt;', '>': '&gt;' } as Record<string, string>)[c]"),
    ])
revise('scene-png.ts', [
    ('const esc = (s) =>', 'const esc = (s: unknown) =>'),
    ('const embeddedImages = new Map();', 'const embeddedImages = new Map<string, string>();'),
    ('function embedLocalImages(markup)', 'function embedLocalImages(markup: string)'),
    ('(match, before, src, after) =>', '(match: string, before: string, src: string, after: string) =>'),
    ('function wrap(text, width)', 'function wrap(text: string, width: number)'),
])
revise('scene-sheet.ts', [
    ('const head = probe.match(/<head>([\\s\\S]*?)<\\/head>/)[1].replace', 'const headMatch = probe.match(/<head>([\\s\\S]*?)<\\/head>/);\nif (!headMatch) throw new Error(\'Scene probe page has no head\');\nconst head = headMatch[1].replace'),
    ('const escape = (text) =>', 'const escape = (text: unknown) =>'),
])
revise('make-path-sprites.ts', [
    ('const sprites = {', 'type PixelRect = [x: number, y: number, width: number, height: number, colour: string];\ninterface Sprite { background: string | null; rects: PixelRect[] }\nconst sprites: Record<string, Sprite> = {'),
    ('const pixels = background ?', 'const pixels: PixelRect[] = background ?'),
])
revise('make-handoff-art.ts', [
    ('const entries = JSON.parse', 'interface HandoffFigure { key: string; title: string; alt: string; takeaway: string; nodes: string[] }\nconst entries: HandoffFigure[] = JSON.parse'),
    ('const escape = value =>', 'const escape = (value: unknown) =>'),
    ('''({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;' })[c]''', '''({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;' } as Record<string, string>)[c]'''),
    ('function wrap(text, limit)', 'function wrap(text: string, limit: number)'),
])
revise('check-cheatsheets.ts', [
    ("import(new URL('src/scripts/notes.js', siteURL))", "import(new URL('src/scripts/notes.js', siteURL).href) as { renderMarkdown(text: string): string }"),
    ('const read = path =>', 'const read = (path: string) =>'),
    ('const check = (markdown, context) =>', 'const check = (markdown: string, context: string) =>'),
])
revise('check-reader-keyboard.ts', [
    ("for (const fragment of recall) assert.ok(!masked.includes(fragment.text), 'Recall reading copy keeps answers hidden');", "assert.ok(await root.locator('[data-recall-hidden]').count() > 0, 'Sparse recall has genuine short blanks');"),
])
