from pathlib import Path
ROOT = Path('/private/tmp/gha-typescript-node-draft/work/site/scripts')
def revise(name, replacements):
    file = ROOT / name
    source = file.read_text()
    for old, new in replacements:
        if old not in source: raise ValueError(f'{name}: missing {old!r}')
        source = source.replace(old, new)
    file.write_text(source)

revise('make-concept-art.ts', [
    ('const escape = value =>', 'const escape = (value: unknown) =>'),
    ('''({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;' }[ch])''', '''(({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;' } as Record<string, string>)[ch])'''),
    ('const n = value =>', 'const n = (value: number) =>'),
    ("const label = (x, y, words, { size = 12, fill = C.ink, mono = false, weight = 400, anchor = 'start' } = {})", "interface LabelOptions { size?: number; fill?: string; mono?: boolean; weight?: number; anchor?: string }\ninterface LineOptions { width?: number; dash?: string; arrow?: boolean }\ninterface PathOptions { width?: number; fill?: string; dash?: string }\nconst label = (x: number, y: number, words: unknown, { size = 12, fill = C.ink, mono = false, weight = 400, anchor = 'start' }: LabelOptions = {})"),
    ('const rect = (x, y, w, h, fill,', 'const rect = (x: number, y: number, w: number, h: number, fill: string,'),
    ('const dot = (x, y, r, fill,', 'const dot = (x: number, y: number, r: number, fill: string,'),
    ('const line = (x1, y1, x2, y2, color = C.muted, { width = 1.5, dash, arrow = false } = {})', 'const line = (x1: number, y1: number, x2: number, y2: number, color = C.muted, { width = 1.5, dash, arrow = false }: LineOptions = {})'),
    ("const path = (d, color, { width = 1.5, fill = 'none', dash } = {})", "const path = (d: string, color: string, { width = 1.5, fill = 'none', dash }: PathOptions = {})"),
    ('const frame = (title, description, body)', 'const frame = (title: string, description: string, body: string[])'),
    ('function terrainGlyph(x, y, type)', 'function terrainGlyph(x: number, y: number, type: string)'),
    ('function fogGlyph(x, y)', 'function fogGlyph(x: number, y: number)'),
    ('const at = p =>', 'const at = (p: { x: number; y: number }) =>'),
    ("for (const [name, make] of [['grid-layers', gridLayers], ['npc-view-cone', viewCone], ['los-samples', losSamples]])", "const drawings: [string, () => string][] = [['grid-layers', gridLayers], ['npc-view-cone', viewCone], ['los-samples', losSamples]];\nfor (const [name, make] of drawings)"),
])
revise('check-reader-keyboard.ts', [
    ('const press = async key =>', 'const press = async (key: string) =>'),
    ("document.querySelector('[data-lesson-notes]').dataset.noteId", "document.querySelector<HTMLElement>('[data-lesson-notes]')?.dataset.noteId"),
    ('document.activeElement.dataset.noteTab', '(document.activeElement as HTMLElement | null)?.dataset.noteTab'),
    ("JSON.parse(await root.getAttribute('data-speedtype-recall'))", "JSON.parse(await root.getAttribute('data-speedtype-recall') ?? '[]') as { text: string }[]"),
    ('(await readable.textContent()).trim()', "(await readable.textContent() ?? '').trim()"),
    ("(await root.locator('.kit-speedtype__code code').textContent()).trim()", "(await root.locator('.kit-speedtype__code code').textContent() ?? '').trim()"),
    ('assert.match(masked, /_/);', 'assert.ok(masked);\n        assert.match(masked, /_/);'),
    ('(await readable.textContent()).includes(fragment.text)', "(await readable.textContent() ?? '').includes(fragment.text)"),
])
revise('check-reader-scenes.ts', [
    ("import { collectReadableBlocks", "import type { ReaderVariants } from '../src/lib/reader-text.ts';\nimport { collectReadableBlocks"),
    ('function htmlFiles(dir)', 'function htmlFiles(dir: string): string[]'),
    ("document.querySelector('.sl-markdown-content');", "document.querySelector<HTMLElement>('.sl-markdown-content');\n  assert.ok(article, file + ': lesson article exists');"),
    ("article.querySelectorAll('figure[data-scene]')", "article.querySelectorAll<HTMLElement>('figure[data-scene]')"),
    ("const variants = JSON.parse(listening.querySelector('[data-reader-transcript-variants]').textContent);", "const transcript = listening.querySelector('[data-reader-transcript-variants]');\n  assert.ok(transcript);\n  const variants: ReaderVariants = JSON.parse(transcript.textContent ?? 'null');"),
    ("cleanReaderText(figure.querySelector('.scene__title').textContent)", "cleanReaderText(figure.querySelector('.scene__title')?.textContent ?? '')"),
    ('figure.contains(block.element)', '!!block.element && figure.contains(block.element)'),
    ("exported[0].media?.src.startsWith", "exported[0].media?.src?.startsWith"),
    ("assert.ok(image.getAttribute('alt').split", "assert.ok((image.getAttribute('alt') ?? '').split"),
    ("assert.ok(readFileSync(join('dist', exported[0].media.src.replace", "assert.ok(exported[0].media?.src);\n      assert.ok(readFileSync(join('dist', exported[0].media.src.replace"),
])
