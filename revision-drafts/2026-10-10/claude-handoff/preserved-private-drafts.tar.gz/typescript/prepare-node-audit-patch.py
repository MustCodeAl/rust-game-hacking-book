from pathlib import Path
import difflib
import json
import subprocess
ROOT = Path('/private/tmp/gha-typescript-node-draft')
SITE = Path('/Users/notlaggy/.codex/worktrees/book-finish/gamehackingacademy.github.io/site')
DRAFT = ROOT / 'work/site'
NAMES = ['check-comment-toggle','check-concept-diagrams','check-contrast','check-handoff-art','check-handoff-scenes','check-reader-accessibility','check-reader-controls','check-reader-keyboard','check-reader-scenes','check-reader-scroll','check-scene-browser','check-simulation-editors','check-speedtype-recall','make-concept-art']
manifest_file = DRAFT / 'scripts/generated-compatibility.json'
before_manifest = manifest_file.read_text()
manifest = json.loads(before_manifest)
manifest['entries'] += [{'entry': name + '.mjs', 'implementation': name + '.ts'} for name in NAMES]
manifest['entries'].sort(key=lambda row: row['entry'])
manifest_file.write_text(json.dumps(manifest, indent=2) + '\n')
subprocess.run(['rtk', 'proxy', 'node', 'scripts/generate-compat-entries.ts'], cwd=DRAFT, check=True)
subprocess.run(['rtk', 'proxy', 'node', 'scripts/generate-compat-entries.ts', '--check'], cwd=DRAFT, check=True)
actions = []
for name in NAMES:
    actions.append((f'site/scripts/{name}.ts', '', (DRAFT / f'scripts/{name}.ts').read_text()))
    actions.append((f'site/scripts/{name}.mjs', (SITE / f'scripts/{name}.mjs').read_text(), (DRAFT / f'scripts/{name}.mjs').read_text()))
actions.append(('site/scripts/generated-compatibility.json', before_manifest, manifest_file.read_text()))
actions.append(('site/tsconfig.audit-tools.json', '', (DRAFT / 'tsconfig.audit-tools.json').read_text()))
fixture = ROOT / 'node-audit-apply-fixture'
fixture.mkdir(exist_ok=True)
chunks = []
for name, before, after in actions:
    chunks.append(''.join(difflib.unified_diff(before.splitlines(keepends=True), after.splitlines(keepends=True), fromfile='a/' + name if before else '/dev/null', tofile='b/' + name)))
    if before:
        file = fixture / name
        file.parent.mkdir(parents=True, exist_ok=True)
        file.write_text(before)
patch = ROOT / 'node-audit-tools-ready.patch'
patch.write_text(''.join(chunks))
subprocess.run(['rtk', 'git', 'init', '-q'], cwd=fixture, check=True)
subprocess.run(['rtk', 'git', 'apply', '--check', str(patch)], cwd=fixture, check=True)
package_file = SITE / 'package.json'
before_package = package_file.read_text()
package = json.loads(before_package)
package['devDependencies']['playwright'] = '1.64.0'
after_package = json.dumps(package, indent=2) + '\n'
(ROOT / 'node-qa-package-pin.patch').write_text(''.join(difflib.unified_diff(before_package.splitlines(keepends=True), after_package.splitlines(keepends=True), fromfile='a/site/package.json', tofile='b/site/package.json')))
report = {'ready': True, 'dependency': 'node-model-tools-ready.patch (15 aliases)', 'newTools': NAMES, 'strictGate': 'tsconfig.audit-tools.json', 'aliasEntries': len(manifest['entries']), 'fileActions': len(actions), 'patchDryCheck': True, 'qa': json.loads((ROOT / 'node-audit-equivalence.json').read_text())}
(ROOT / 'node-audit-tools-ready.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: v for k, v in report.items() if k != 'qa'}, indent=2))
