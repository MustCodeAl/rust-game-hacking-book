# Native TypeScript Node tools: next 22

Apply `node-build-tools-ready.patch` first (7 aliases), then
`node-model-tools-ready.patch` (15 aliases), then
`node-audit-tools-ready.patch` (29 aliases). No shared runtime, content, public
quiz modules, site build, publication, or labs were changed/run here.

## Gates executed

- TypeScript 5.9.3 strict/noEmit/verbatimModuleSyntax/erasableSyntaxOnly:
  `tsconfig.model-tools.json` and `tsconfig.audit-tools.json`, both exit 0.
- Native Node 26.10.0 generated entries and byte verification: 15 and 29 entries.
- Model/art subset: 16 successful original/typed command executions in isolated
  private fixtures. 54 byte-identical files: 45 SVG figures, four sprites,
  two scene PNG sheets, and three HTML sheets. Existing independent checks:
  15 chat cases, 155 cheatsheets, 173 defence model cases, 106 wall/clip cases.
- Audit subset: no authored `any`/suppression, original assertions retained;
  29 before/after recall lexical/focus oracle cases; six byte-identical SVG/PNG
  art files. All original CSS Color4/Modern canvas paths retained.
- Patches dry-checked against explicit current-source preimages and manifest
  dependency preimages. Parent runs assembled browser gates.

## Material change beyond types

Scene PNG/HTML exporters still requested removed `.mjs` scenes dynamically.
They now enumerate/import `.ts` files and use URL.href for native imports.
The original comparison fixtures adapt that stale suffix only; generated
pictures, captions, dimensions, and contact-sheet bytes match.

Additional runtime statements only validate the expected page element/text or
model result before using it; sparse masks, rendering logic, timing limits,
saved keys and existing gate assertions remain intact.

## Dependencies and remaining work

`node-qa-package-pin.patch` adds exact Playwright 1.64.0 to the CURRENT package
devDependencies. Type-only Playwright imports stay in Node QA tools; axe remains
an external optional runtime path, with a narrow typed result interface.

Ten tools remain: seven depend on root-owned browser/pure client types, plus
quiz-balance, quiz-concept-check and check-lesson-quizzes. The last checker will
be rebased to root's additive pool preservation proofs. Root owns public quiz
compatibility generation; this manifest only owns site/scripts/*.mjs.

Machine reports: node-model-tools-ready.json, node-model-equivalence.json,
node-audit-tools-ready.json, node-audit-equivalence.json.
