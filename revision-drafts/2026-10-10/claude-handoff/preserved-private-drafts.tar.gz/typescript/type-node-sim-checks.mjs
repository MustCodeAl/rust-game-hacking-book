import fs from 'node:fs';
import ts from '/Users/notlaggy/.codex/worktrees/book-finish/gamehackingacademy.github.io/site/node_modules/typescript/lib/typescript.js';
const root = '/private/tmp/gha-typescript-node-draft/work/site/scripts/';
function revise(name, replacements) {
  const file = root + name;
  let code = fs.readFileSync(file, 'utf8');
  for (const [before, after] of replacements) {
    if (!code.includes(before)) throw new Error(name + ': missing ' + before);
    code = code.replaceAll(before, after);
  }
  const tree = ts.createSourceFile(file, code, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  const patches = [];
  function visit(node) {
    if (ts.isAwaitExpression(node) && ts.isCallExpression(node.expression) && ts.isPropertyAccessExpression(node.expression.expression) && node.expression.expression.name.text === 'textContent') {
      const start = node.getStart(tree), end = node.getEnd();
      patches.push({ start, end, text: 'requireText(' + code.slice(start, end) + ')' });
    }
    ts.forEachChild(node, visit);
  }
  visit(tree);
  for (const patch of patches.sort((a, b) => b.start - a.start)) code = code.slice(0, patch.start) + patch.text + code.slice(patch.end);
  code = code.replace("import assert from 'node:assert/strict';", "import assert from 'node:assert/strict';\nimport type { Locator } from 'playwright';\nconst requireText = (text: string | null): string => { assert.notEqual(text, null, 'Expected page text exists'); return text!; };");
  fs.writeFileSync(file, code);
}
revise('check-concept-diagrams.ts', [
  ['const load = async (path, lab) =>', 'const load = async (path: string, lab: string) =>'],
  ['const set = async (root, key, value) =>', 'const set = async (root: Locator, key: string, value: string | number) =>'],
  ['.evaluate((input, value) =>', '.evaluate((input: HTMLInputElement, value) =>'],
  ['const shot = async (root, name) =>', 'const shot = async (root: Locator, name: string) =>'],
  ["for (const [path, lab, key, changed, expected] of [['pages/4/03/', 'grid-lab', 'width', 3, 'Result: 17'], ['pages/3/07/', 'utf8-lab', 'text', '🙂🙂🙂🙂🙂🙂🙂🙂', 'Result: 5']])", "const resetCases: [string, string, string, string | number, string][] = [['pages/4/03/', 'grid-lab', 'width', 3, 'Result: 17'], ['pages/3/07/', 'utf8-lab', 'text', '🙂🙂🙂🙂🙂🙂🙂🙂', 'Result: 5']];\n    for (const [path, lab, key, changed, expected] of resetCases)"],
  ['const place = async (slot, token) =>', 'const place = async (slot: number, token: string) =>'],
  ['const examples = [', 'const examples: [number, string, number, string][] = ['],
]);
revise('check-handoff-scenes.ts', [
  ['const shot = async (root, name) =>', 'const shot = async (root: Locator, name: string) =>'],
  ['const picture = root =>', 'const picture = (root: Locator) =>'],
  ['const opacity = locator =>', 'const opacity = (locator: Locator) =>'],
  ['const open = async (path, name) =>', 'const open = async (path: string, name: string) =>'],
  ['const toggle = async (root, key, value) =>', 'const toggle = async (root: Locator, key: string, value: boolean) =>'],
  ['const bound = async (root, key, last) =>', 'const bound = async (root: Locator, key: string, last: boolean) =>'],
  ['const reset = async (root, original) =>', 'const reset = async (root: Locator, original: Awaited<ReturnType<typeof picture>>) =>'],
  ['const expectations = [[true', 'const expectations: [boolean, boolean, boolean, number][] = [[true'],
]);
revise('check-simulation-editors.ts', [
  ['const shot = async (root, name) =>', 'const shot = async (root: Locator, name: string) =>'],
  ['const click = async locator =>', 'const click = async (locator: Locator) =>'],
  ['const input = async (locator, value) =>', 'const input = async (locator: Locator, value: string | number) =>'],
  ['.evaluate((node, value) =>', '.evaluate((node: HTMLInputElement, value) =>'],
  ['const picture = root =>', 'const picture = (root: Locator) =>'],
]);
