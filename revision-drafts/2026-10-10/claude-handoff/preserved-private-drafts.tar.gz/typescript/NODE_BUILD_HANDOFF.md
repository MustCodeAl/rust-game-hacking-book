# First coherent Node CLI subset

Apply after shared-ready.patch: seven build/publish implementations in strict native .ts plus a typed deterministic compatibility-entry generator. Existing public .mjs command names are generated re-export entries, with explicit @generated comments and generated-compatibility.json ownership manifest. Native Node26 loads the typed logic without a separate toolchain. No package scripts renamed; no source publishing/build behavior invoked during validation.

Strict gate: node site/node_modules/typescript/bin/tsc -p site/tsconfig.build-tools.json. All eight authored tools pass TS5.9.3 strict/noEmit/verbatimModuleSyntax/erasableSyntaxOnly. Run node site/scripts/generate-compat-entries.ts --check to verify emitted aliases. Generator output and verification both pass and are deterministic.

Meaningful isolated Node26 compatibility equivalence: old/current write-docs-json and chat-widget injector compared with generated.mjs→typed implementations; six CLI executions, three byte-identical output artifacts,16chapter/navigationgroups and158listedpages, widget repeat-run idempotency. No shared dist build, publisher invocation, lab/example binary execution or Git mutation.

Prerender's protocol messages/targets/commands/replies, timers, child lifecycle, server address and serialized drawing function are typed and guarded. The serialized renderer uses a local window intersection, avoiding clashes with Root's upcoming browser-global declarations. Reader fallback/edition scripts use typed DOM and transcript/media interfaces. Current shared imports/identity metadata are preserved.

Remaining32Node tools are still private drafts; do not apply them from the working tree. Later slices extend the same compatibility manifest/generator. Root must run assembled build/browser/publisher gates before publication.
