IDE reader batch — baseline e9f44717

Production patch: phase4-ide-reader.patch; exact 17-file list in phase4-files.json.

Modern upgrades every existing CodeTrace, and uses DebuggerStepper/IDECodeWindow as the actual existing CpuStepLab view. Original retains the previous controls/diagram. All default CodeTrace steps, CPU states and clock timing remain server-rendered. Clock progression requires an explicit click. No autoplay. Register pairing and IP marks use semantic tokens without changing geometry.

Verification: scoped strict TypeScript with noUncheckedIndexedAccess/exactOptionalPropertyTypes exits 0. Private npm build exits 0, 334 pages / 155 listening articles / 991 silent visuals. Actual Chromium420/1280: 80 clicks, 14 keys, 20 input changes, five bounded RAM bytes and four invalid inputs per width, Prev/Next/Reset/notches/Home/End, register/IP pairing, rising/falling clock behaviour, code copy, semantic-toggle geometry, Original restore; zero page errors or horizontal overflow. Additional built-in IDE frame Copy via focused Enter writes the complete five-line source. All256 CPU-byte models and145 default trace references/848 recorded states checked. JS-disabled CPU and CodeTrace content checked. Screenshots in screenshots/ inspected.

Global Astro check exits1 with12 existing diagnostics in astro.config.mjs, FormulaBuilder, ReaderTools, SortBoard, Visual, GitHub and LinkButton; no diagnostics in this batch's owned files. Source migration is being handled separately by root. No claim of full-project strict success.

Private source/dist/dependencies only. No MDX edits, commits, publication or lab execution. HUD/header/cheatsheet/support additions are a separate pending phase5 patch.
