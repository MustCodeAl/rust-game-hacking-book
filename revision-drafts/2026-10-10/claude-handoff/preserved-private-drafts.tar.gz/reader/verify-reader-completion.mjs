import assert from 'node:assert/strict';
import { mkdirSync, writeFileSync } from 'node:fs';
import { chromium } from './site/node_modules/playwright/index.mjs';
import { cpuDebuggerSteps } from './site/src/data/cpu-debugger.ts';
import { validDebuggerSteps } from './site/src/data/debugger-model.ts';
import { defaultTraceReference } from './site/src/data/trace-reference.ts';
import { TRACES } from './site/src/scripts/code-trace.js';
const origin='http://127.0.0.1:8785', base=origin+'/rust-game-hacking-book/';
const output='/private/tmp/gha-reader-completion-draft/screenshots';mkdirSync(output,{recursive:true});
for(let byte=0;byte<256;byte++){const steps=cpuDebuggerSteps(byte);assert.equal(steps.length,5);assert.ok(validDebuggerSteps(steps,5));assert.deepEqual(steps.map(s=>s.registers.PC),['0x02','0x03','0x03','0x04','0x04']);assert.deepEqual(steps.map(s=>s.registers.cycles),[2,3,3,4,5]);assert.equal(steps[4].registers.A,byte);assert.equal(steps[4].registers.Z,byte===0?1:0);}
const references=Object.values(TRACES).map(defaultTraceReference);assert.ok(references.every(r=>r.length>0));
assert.equal(validDebuggerSteps([{line:1,description:'bad',registers:{PC:Infinity}}],5),false);
assert.equal(validDebuggerSteps([{line:1,description:'bad',registers:{PC:1},variables:{PC:2}}],5),false);
const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
const receipts=[];let clicks=0,keys=0,changes=0;
const click=async loc=>{await loc.click();clicks++;};
const key=async(page,value)=>{await page.keyboard.press(value);keys++;};
const fill=async(loc,value)=>{await loc.fill(String(value));changes++;};
try{for(const width of [420,1280]){
 const context=await browser.newContext({viewport:{width,height:950},reducedMotion:'reduce',permissions:['clipboard-read','clipboard-write']});
 await context.route('https://**/*',route=>route.abort());await context.addInitScript(()=>{localStorage.setItem('gha-appearance','modern');localStorage.setItem('gha-motion','off');});
 const page=await context.newPage(),errors=[];page.setDefaultTimeout(6000);page.on('pageerror',e=>errors.push(e.message));
 await page.goto(base+'pages/14/11/',{waitUntil:'domcontentloaded'});
 const cpu=page.locator('[data-cpu-step]'),debuggerWidget=cpu.locator('[data-debugger-stepper]');await debuggerWidget.waitFor({state:'visible'});
 await page.waitForFunction(()=>document.querySelector('[data-debugger-stepper]')?.dataset.debuggerReady==='true');
 const readValues=()=>debuggerWidget.locator('[data-debugger-values]').evaluate(dl=>Object.fromEntries(Array.from(dl.children).map(row=>[row.querySelector('dt').textContent.trim(),row.querySelector('dd').textContent.trim()])));
 for(const byte of [0,1,10,42,255]){
  await fill(cpu.locator('[data-cpu-value]'),byte);assert.equal(await debuggerWidget.locator('[data-debugger-position]').textContent(),'1 / 5');
  for(let n=0;n<4;n++)await click(debuggerWidget.locator('[data-debugger-next]'));
  const values=await readValues();assert.equal(values.A,String(byte));assert.equal(values.Z,byte===0?'1':'0');assert.equal(values.PC,'0x04');assert.equal(values.cycles,'5');
  assert.equal(await debuggerWidget.locator('.is-debugger-current').count(),1);assert.equal(await debuggerWidget.locator('[data-debugger-next]').isDisabled(),true);
  assert.match(await debuggerWidget.locator('[data-debugger-diff]').textContent(),/cycles:.*4.*5/);
  await click(debuggerWidget.locator('[data-debugger-previous]'));assert.equal((await readValues()).A,'0');
  await click(debuggerWidget.locator('[data-debugger-reset]'));assert.equal((await readValues()).PC,'0x02');
 }
 for(const invalid of ['256','-1','1.5','']){await fill(cpu.locator('[data-cpu-value]'),invalid);assert.equal(await debuggerWidget.locator('[data-debugger-next]').isDisabled(),true);assert.match(await debuggerWidget.locator('[data-debugger-description]').textContent(),/whole byte/);}
 await fill(cpu.locator('[data-cpu-value]'),10);await click(debuggerWidget.locator('[data-debugger-select="4"]'));
 await debuggerWidget.locator('[data-debugger-select="4"]').focus();await key(page,'Home');assert.equal((await readValues()).PC,'0x02');await key(page,'End');assert.equal((await readValues()).A,'10');
 const pc=debuggerWidget.locator('[data-debugger-values] [data-register-name="PC"]');await pc.focus();assert.ok(await debuggerWidget.locator('.is-register-linked').count()>=2);assert.equal(await debuggerWidget.locator('.is-instruction-linked').count(),1);
 await key(page,'ArrowLeft');assert.equal(await page.evaluate(()=>document.activeElement?.dataset.registerName),'PC');
 const dimensions=await debuggerWidget.locator('.debugger-stepper__grid').evaluate(el=>Array.from(el.children).map(child=>{const r=child.getBoundingClientRect();return{x:r.x,y:r.y,width:r.width,height:r.height};}));
 assert.equal(width>=1024?Math.abs(dimensions[0].y-dimensions[1].y)<2:dimensions[1].y>dimensions[0].y,true);
 await debuggerWidget.locator('[data-debugger-next]').focus();const before=await debuggerWidget.boundingBox();await key(page,'Alt+h');const after=await debuggerWidget.boundingBox();assert.ok(Math.abs(before.width-after.width)<1&&Math.abs(before.height-after.height)<1);await key(page,'Alt+h');
 await cpu.scrollIntoViewIfNeeded();await page.screenshot({path:output+'/cpu-'+width+'.png'});
 await click(cpu.locator('.cpu-step__clock-modern > summary'));const wave=cpu.locator('[data-logic-waveform]');await click(wave.locator('[data-wave-input]'));await click(wave.locator('[data-wave-step]'));assert.equal(await wave.getAttribute('data-wave-stored'),'1');
 await click(wave.locator('[data-wave-input]'));assert.equal(await wave.getAttribute('data-wave-stored'),'1');await click(wave.locator('[data-wave-step]'));assert.equal(await wave.getAttribute('data-wave-stored'),'1');await click(wave.locator('[data-wave-step]'));assert.equal(await wave.getAttribute('data-wave-stored'),'0');await click(wave.locator('[data-wave-reset]'));assert.equal(await wave.getAttribute('data-wave-clock'),'0');
 await page.evaluate(()=>{document.documentElement.dataset.academyAppearance='original';document.dispatchEvent(new Event('academy:preferences'));});assert.equal(await debuggerWidget.isVisible(),false);assert.equal(await cpu.locator(':scope > svg').isVisible(),true);
 await page.goto(base+'pages/2/02/',{waitUntil:'domcontentloaded'});const trace=page.locator('[data-code-trace]').first();await trace.locator('[data-trace-timeline]').waitFor({state:'visible'});
 const total=Number(await trace.getAttribute('data-steps'));await click(trace.locator('[data-trace-select="'+total+'"]'));assert.equal(await trace.getAttribute('data-step'),String(total));await trace.locator('[aria-current="step"][data-trace-select]').focus();await key(page,'Home');assert.equal(await trace.getAttribute('data-step'),'1');await key(page,'ArrowRight');assert.equal(await trace.getAttribute('data-step'),'2');
 assert.ok(await trace.locator('.trace-debugger__mutation del').count()>0);const badge=trace.locator('.code-trace__name[data-trace-register]').first();await badge.focus();assert.ok(await trace.locator('.is-register-linked').count()>=2);
 await click(trace.locator('.trace-debugger__copy'));await page.waitForFunction(()=>Array.from(document.querySelectorAll('.trace-debugger__copy-status')).some(el=>el.textContent==='Code copied.'));assert.ok((await page.evaluate(()=>navigator.clipboard.readText())).length>10);
 await trace.scrollIntoViewIfNeeded();await page.screenshot({path:output+'/trace-'+width+'.png'});
 await page.evaluate(()=>{document.documentElement.dataset.academyAppearance='original';document.dispatchEvent(new Event('academy:preferences'));});assert.equal(await trace.locator('[data-trace-timeline]').isVisible(),false);
 assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);assert.deepEqual(errors,[]);receipts.push({width,cpuBytes:5,invalidBytes:4,clockEdges:true,traceTimeline:true,pairing:true,copy:true,keyboard:true,geometry:true,originalRestore:true,pageErrors:errors.length});await context.close();
 }
 const nojs=await browser.newContext({javaScriptEnabled:false,viewport:{width:420,height:950}});await nojs.route('https://**/*',route=>route.abort());const page=await nojs.newPage();await page.goto(base+'pages/14/11/');assert.equal(await page.locator('.cpu-step__reference tbody tr').count(),5);await page.goto(base+'pages/2/02/');assert.ok(await page.locator('.code-trace__fallback pre').count()>0);assert.ok(await page.locator('[data-trace-reference][open] li').count()>0);await nojs.close();
 console.log(JSON.stringify({modelBytes:256,traceReferences:references.length,recordedSteps:references.reduce((n,r)=>n+r.length,0),clicks,keys,changes,receipts,noScript:true}));writeFileSync('/private/tmp/gha-reader-completion-draft/ide-receipt.json',JSON.stringify({modelBytes:256,traceReferences:references.length,recordedSteps:references.reduce((n,r)=>n+r.length,0),clicks,keys,changes,receipts,noScript:true},null,2));
}finally{await browser.close();}
